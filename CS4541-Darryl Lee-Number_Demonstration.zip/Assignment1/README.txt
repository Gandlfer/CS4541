Date: 09/17/2020  
Class: CS4541  
Assignment: Assignment 1 - Number Demonstration 
Author(s): Darryl Ming Sen Lee 

Command to compile and run code:
	-make all
	-make run

Warnings: There are a couple of warnings but it was supposed to happen.

References: No references 

Results:
	Problem 1:
		Expected: 2.5000000000
		Result: 2.5000000000
	
	Problem 2:
		Expected : -0.1000000000
		Result: -0.1000000015
	
	Problem 3:
		Expected: 
			0.333333
			0.333333
		Result: 
			0.000000
			0.333333

	Problem 4:
		Expected: 
			9999999.3399999999
			9999999.3399999999
		Result:
			9999999.340000
			9999999.000000

	Problem 5:
		Expected:
			900000000
			1600000000
			2500000000
			3600000000
			4900000000
		Result:
			900000000
			1600000000
			-1794967296
			-694967296
			605032704

	Problem 6:
		Expected:
			100000000000000000000.000000
			100000000003500000000.000000
			103500000000000000000.000000
			103500000000000000000.000000
		Result:
			100000002004087734272.000000
			100000002004087734272.000000
			103500002601996386304.000000
			100000002004087734272.000000

