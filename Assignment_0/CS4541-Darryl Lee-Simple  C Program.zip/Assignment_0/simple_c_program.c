/*
Date: 09/11/2020  
Class: CS4541  
Assignment: Assignment 0 - Simple C Program  
Author(s): Darryl Ming Sen Lee 
*/
#include<stdio.h>

int main(){
    printf("Hello World!\n");

    return 0;
}
