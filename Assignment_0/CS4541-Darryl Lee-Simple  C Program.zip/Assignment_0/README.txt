Date: 09/11/2020  
Class: CS4541  
Assignment: Assignment 0 - Simple C Program  
Author(s): Darryl Ming Sen Lee 

Command to run the code: 
    make all
    make run 