Date: 10/23/2020  
Class: CS4541  
Assignment: Assignment 2 - Cache Simulator  
Author(s): Darryl Ming Sen Lee 
Email: darrylmingsen.lee@wmich.edu

Coding Guidelines: Non Used
Language Used: Python
Version: 3.8.5
IDE Used: Visual Studio Code (Code was tested on Linux Terminal)

Instruction:
        1. trace file has to be in the same directory as Application.py
        2. No IDE required to run the code. Code can be run on Linux Terminal

Command to compile and run code:
        python3 Application.py [-hv] -s <s> -E <E> -b <b> -t <tracefile>

Warning: None

Reference:
        1. https://www.rapidtables.com/convert/number/hex-to-binary.html
           Using this website to test the hex to bin for accuracy
        2. https://www.w3schools.com/python/ref_file_readlines.asp
           Refered this site to understand how to readfile line by line
        3. https://www.tutorialspoint.com/python/python_command_line_arguments.htm
           Refered this site to understand how to get command line arguments